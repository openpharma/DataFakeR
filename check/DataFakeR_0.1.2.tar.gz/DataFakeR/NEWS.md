# DataFakeR 0.1.2

- Built in support for `levels_ratio` parameter

# DataFakeR 0.1.1

- Support for native R column types
- Possibility to dump schema from list of tables

# DataFakeR 0.1

- Source schema structure from Database
- Four ways to customize simulation method
- Extensive configuration options
