#' Generate fake data based on provided schema specification
#'
#' @name DataFakeR-package
#' @importFrom magrittr %>%

globalVariables(c(":=", "!!", ".data", "nodes"))

NULL
