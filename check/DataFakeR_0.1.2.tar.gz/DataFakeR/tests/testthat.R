library(testthat)
library(mockery)
library(DataFakeR)

test_check("DataFakeR")
